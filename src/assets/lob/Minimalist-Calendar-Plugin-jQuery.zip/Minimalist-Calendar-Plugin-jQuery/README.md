# CalendarJS
An implementation of a Calendar Widget in HTML using only jQuery (3.3.1).
